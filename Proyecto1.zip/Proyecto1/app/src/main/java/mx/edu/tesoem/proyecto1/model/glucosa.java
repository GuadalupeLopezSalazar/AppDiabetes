package mx.edu.tesoem.proyecto1.model;

public class glucosa {
    private String fechaHora;
    private int valor;
    private String rango;
    private String check;

    public glucosa() {
        // Constructor vacío requerido para Firestore
    }

    public glucosa(String fechaHora, int valor, String rango, String check) {
        this.fechaHora = fechaHora;
        this.valor = valor;
        this.rango = rango;
        this.check = check;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public String getRango() {
        return rango;
    }

    public void setRango(String rango) {
        this.rango = rango;
    }

    public String getCheck() {
        return check;
    }

    public void setCheck(String check) {
        this.check = check;
    }
}
