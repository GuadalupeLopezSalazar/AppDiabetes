package mx.edu.tesoem.proyecto1;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CheckFragment extends DialogFragment {

    CheckBox checkBebidas;
    CheckBox checkSnacks;
    CheckBox checkGrasas;
    CheckBox checkCarbo;
    CheckBox checkAlimentos;
    Button btnAceptar;

    FirebaseFirestore firestore;

    String documentId;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            documentId = bundle.getString("documentId");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_check, container, false);

        checkBebidas = view.findViewById(R.id.checkBebidas);
        checkSnacks = view.findViewById(R.id.checkSnacks);
        checkGrasas = view.findViewById(R.id.checkGrasas);
        checkCarbo = view.findViewById(R.id.checkCarbo);
        checkAlimentos = view.findViewById(R.id.checkAlimentos);
        btnAceptar = view.findViewById(R.id.btnAceptarAlimentos);

        firestore = FirebaseFirestore.getInstance();

        // Configuración del clic del botón Aceptar
        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("CheckFragment", "Botón Aceptar clicado");
                guardarAlimentosSeleccionados();
            }
        });

        return view;
    }

    private void guardarAlimentosSeleccionados() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null && documentId != null) {
            String nombreUsuario = user.getDisplayName();
            String userId = nombreUsuario.replaceAll("\\s", "");

            // Obtener la fecha y hora actual para usarla como ID de subcolección
            String fechaHoraActual = obtenerFechaHoraActual();

            // Referencia a la colección de alimentos dentro del documento de registrosGlucosa
            CollectionReference alimentosRef = firestore.collection("Usuario")
                    .document(userId).collection("registrosGlucosa")
                    .document(fechaHoraActual).collection("alimentos");

            Map<String, Object> alimentos = new HashMap<>();
            alimentos.put("Bebidas azucaradas", checkBebidas.isChecked());
            alimentos.put("Snacks y dulces", checkSnacks.isChecked());
            alimentos.put("Grasas saturadas y trans", checkGrasas.isChecked());
            alimentos.put("Carbohidratos refinados", checkCarbo.isChecked());
            alimentos.put("Alimentos procesados", checkAlimentos.isChecked());

            alimentosRef.add(alimentos)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            // Mostrar el mensaje específico después de guardar los alimentos
                            mostrarMensajeEspecifico();
                            dismiss(); // Cerrar el fragmento
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(requireContext(), "Error al registrar los datos: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            Log.e("CheckFragment", "Error al registrar los datos", e);
                        }
                    });
        } else {
            Toast.makeText(requireContext(), "Usuario nulo o documentoId nulo", Toast.LENGTH_SHORT).show();
        }
    }

    // Método para mostrar el mensaje específico en un AlertDialog
    private void mostrarMensajeEspecifico() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Advertencia")
                .setMessage("Basado en los alimentos que registraste, tu nivel de glucosa parece alto después de esta comida. Recomendamos evitar estos alimentos, ya que pueden ser perjudiciales para tu salud.")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Acción opcional
                    }
                })
                .show();
    }

    // Método para obtener la fecha y la hora actual
    private String obtenerFechaHoraActual() {
        Date fechaHoraActual = new Date();
        SimpleDateFormat formato = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
        return formato.format(fechaHoraActual);
    }
}
