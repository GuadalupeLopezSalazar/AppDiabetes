package mx.edu.tesoem.proyecto1.model;
public class presion {

    String fechaHora;
    String presion; // Cambiado a String

    public presion(String fechaHora, String presion) {
        this.fechaHora = fechaHora;
        this.presion = presion;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getPresion() {
        return presion;
    }

    public void setPresion(String presion) {
        this.presion = presion;
    }

    public presion (){

    }

}
