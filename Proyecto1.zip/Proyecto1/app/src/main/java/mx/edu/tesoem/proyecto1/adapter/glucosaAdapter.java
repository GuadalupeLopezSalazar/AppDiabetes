package mx.edu.tesoem.proyecto1.adapter;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

import java.util.Objects;

import mx.edu.tesoem.proyecto1.CrearRegGlucosa;
import mx.edu.tesoem.proyecto1.R;
import mx.edu.tesoem.proyecto1.model.glucosa;

public class glucosaAdapter extends FirestoreRecyclerAdapter<glucosa, glucosaAdapter.ViewHolder> {

    private Context mContext;

    public glucosaAdapter(@NonNull FirestoreRecyclerOptions<glucosa> options, Context context) {
        super(options);
        this.mContext = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull glucosa model) {
        holder.bind(model);

        boolean antesDeComer = Objects.equals(model.getCheck(), "Antes de comer");
        boolean despuesDeComer = Objects.equals(model.getCheck(), "Después de comer");

        int imagen = obtenerImagenPorValor(model.getValor(), antesDeComer, despuesDeComer);
        holder.descripcion.setImageResource(imagen);

        holder.imageViewP4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSnapshots().getSnapshot(position).getReference().delete();
            }
        });

        holder.imageViewP5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String documentId = getSnapshots().getSnapshot(position).getId();
                String fechaHora = model.getFechaHora();
                int valor = model.getValor();

                CrearRegGlucosa fragment = new CrearRegGlucosa();
                Bundle bundle = new Bundle();
                bundle.putString("documentId", documentId);
                bundle.putString("fechaHora", fechaHora);
                bundle.putInt("valor", valor);
                fragment.setArguments(bundle);
                fragment.show(((FragmentActivity) mContext).getSupportFragmentManager(), "editar registro");
            }
        });
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_glucosa, parent, false);
        return new ViewHolder(view);
    }

    private int obtenerImagenPorValor(int valor, boolean antesDeComer, boolean despuesDeComer) {
        Log.d("GlucosaAdapter", "Valor: " + valor + ", Antes de comer: " + antesDeComer + ", Después de comer: " + despuesDeComer);

        if (antesDeComer) {
            if (valor < 70) {
                return R.drawable.bajo;
            } else if (valor >= 70 && valor < 100) {
                return R.drawable.normal;
            } else if (valor >= 100 && valor <= 125) {
                return R.drawable.regular; // Prediabetes
            } else {
                return R.drawable.alto; // Diabetes
            }
        } else if (despuesDeComer) {
            if (valor < 70) {
                return R.drawable.bajo;
            } else if (valor >= 70 && valor < 140) {
                return R.drawable.normal;
            } else if (valor >= 140 && valor <= 199) {
                return R.drawable.regular; // Prediabetes
            } else {
                return R.drawable.alto; // Diabetes
            }
        } else { // Cualquier momento del día
            if (valor < 70) {
                return R.drawable.bajo;
            } else if (valor >= 70 && valor < 140) {
                return R.drawable.normal;
            } else if (valor >= 140 && valor < 250) {
                return R.drawable.regular; // Prediabetes
            } else {
                return R.drawable.alto; // Hiperglucemia
            }
        }
    }



    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView fechaHoraTextView;
        private TextView valorTextView;
        private ImageView descripcion;
        private ImageView imageViewP4;
        private ImageView imageViewP5;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            fechaHoraTextView = itemView.findViewById(R.id.txtFyH);
            valorTextView = itemView.findViewById(R.id.txtIndicador);
            descripcion = itemView.findViewById(R.id.descripcion);
            imageViewP4 = itemView.findViewById(R.id.imageView4);
            imageViewP5 = itemView.findViewById(R.id.imageView5);
        }

        public void bind(glucosa model) {
            fechaHoraTextView.setText(model.getFechaHora());
            valorTextView.setText(String.valueOf(model.getValor()));
        }
    }
}
