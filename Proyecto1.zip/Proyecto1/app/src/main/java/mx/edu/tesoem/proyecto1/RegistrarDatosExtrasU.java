package mx.edu.tesoem.proyecto1;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class RegistrarDatosExtrasU extends DialogFragment {

    EditText edtPeso, edtAltura, edtEdad;
    ImageView btnRegresar;
    Button btn_DatosE;
    private FirebaseFirestore mfirestore;
    private RegistrarDatosExtrasListener listener;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_registrar_datos_extras_u,
                container, false);
        mfirestore = FirebaseFirestore.getInstance();

        edtPeso = v.findViewById(R.id.edtPeso);
        edtAltura = v.findViewById(R.id.edtAltura);
        edtEdad = v.findViewById(R.id.edtEdad);
        btn_DatosE = v.findViewById(R.id.btn_DatosE);
        btnRegresar = v.findViewById(R.id.img_btnRegresar4);

        btn_DatosE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String peso = edtPeso.getText().toString();
                String altura = edtAltura.getText().toString();
                String edad = edtEdad.getText().toString();

                if (!peso.isEmpty() && !altura.isEmpty() && !edad.isEmpty()) {
                    enviarRegDatosE(peso, altura, edad);
                } else {
                    Toast.makeText(getContext(), "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        return v;
    }

    private void enviarRegDatosE(String peso, String altura, String edad) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreUsuario = user.getDisplayName();
            String userId = nombreUsuario.replaceAll("\\s", "");

            DocumentReference userDocRef = mfirestore.collection("Usuario").document(userId);
            CollectionReference datosExtraRef = userDocRef.collection("datosExtra");

            Map<String, Object> datos = new HashMap<>();
            datos.put("peso", peso);
            datos.put("altura", altura);
            datos.put("edad", edad);
            datos.put("timestamp", System.currentTimeMillis()); // Añadir timestamp

            datosExtraRef.add(datos)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            if (listener != null) {
                                listener.onDatosExtrasRegistrados();
                            }
                            Toast.makeText(getContext(),
                                    "Datos registrados exitosamente", Toast.LENGTH_SHORT).show();
                            dismiss();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getContext(),
                                    "Error al registrar los datos", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    public void setRegistrarDatosExtrasListener(RegistrarDatosExtrasListener listener) {
        this.listener = listener;
    }

    public interface RegistrarDatosExtrasListener {
        void onDatosExtrasRegistrados();
    }
}
