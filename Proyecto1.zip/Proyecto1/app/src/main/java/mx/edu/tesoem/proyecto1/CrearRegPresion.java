package mx.edu.tesoem.proyecto1;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CrearRegPresion extends DialogFragment {

    TextView txtFechaHora, txtPresion;

    NumberPicker numPickerSistolica, numPickerDiastolica;
    Button btnEnviarRegP;
    ImageView imageView;
    private int presion;
    private String documentId;
    ImageView btnRegresar;

    private FirebaseFirestore mfirestore;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_crear_reg_presion, container, false);
        mfirestore = FirebaseFirestore.getInstance();

        // Referenciar vistas

        txtFechaHora = v.findViewById(R.id.txtFechaHora);
        txtPresion = v.findViewById(R.id.txtPresion);
        numPickerSistolica = v.findViewById(R.id.numPickerSistolica);
        numPickerDiastolica = v.findViewById(R.id.numPickerDiastolica);
        imageView = v.findViewById(R.id.imageView);
        btnEnviarRegP = v.findViewById(R.id.btnAceptar);
        btnRegresar = v.findViewById(R.id.img_btnRegresar5);

        Bundle bundle = getArguments();
        if (bundle != null) {
            documentId = bundle.getString("documentId");
            presion = bundle.getInt("presion");
        }

        // Configurar NumberPickers

        numPickerSistolica.setMinValue(119);
        numPickerSistolica.setMaxValue(160);
        numPickerDiastolica.setMinValue(79);
        numPickerDiastolica.setMaxValue(100);

        // Obtener y mostrar la fecha y hora actual

        String fechaHoraActual = obtenerFechaHoraActual();
        txtFechaHora.setText(fechaHoraActual);

        numPickerSistolica.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                actualizarPresion();
            }
        });

        numPickerDiastolica.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                actualizarPresion();
            }
        });

        btnEnviarRegP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int valorSistolica = numPickerSistolica.getValue();
                int valorDiastolica = numPickerDiastolica.getValue();
                String presion = valorSistolica + "/" + valorDiastolica;
                if (documentId != null && !documentId.isEmpty()){
                    actualizarRegPre(documentId, presion);
                }else {
                    enviarRegP(presion);
                }

            }
        });

        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        return v;
    }



    private void actualizarPresion() {
        int valorSistolica = numPickerSistolica.getValue();
        int valorDiastolica = numPickerDiastolica.getValue();
        String presion = valorSistolica + "/" + valorDiastolica;
        txtPresion.setText(presion);

        // Definir las imágenes según los rangos
        if (valorSistolica == 120 && valorDiastolica == 80) {
            imageView.setImageResource(R.drawable.normal);
        } else if (valorSistolica >= 120 && valorSistolica <= 129 && valorDiastolica >= 80 && valorDiastolica <= 84) {
            imageView.setImageResource(R.drawable.regular);
        } else if (valorSistolica >= 130 && valorSistolica <= 139 && valorDiastolica >= 85 && valorDiastolica <= 89) {
            imageView.setImageResource(R.drawable.alto);
        } else if (valorSistolica >= 140 && valorSistolica <= 159 && valorDiastolica >= 90 && valorDiastolica <= 99) {
            imageView.setImageResource(R.drawable.critico);

        }
    }


    // Obtiene la instancia del usuario actualmente autenticado a través de Firebase Authentication
    // Verifica que el usuario no sea nulo, obtiene su nombre de usuario y lo utiliza para construir una identificación de usuario al eliminar los espacios en blanco
    // Se obtiene una referencia al documento del usuario en la colección "Usuario" y una referencia a la subcolección "registrosPresion"
    // Se crea un mapa de datos y se añaden a un nuevo documeto

    private void enviarRegP(String presion) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreUsuario = user.getDisplayName();
            String userId = nombreUsuario.replaceAll("\\s", "");
            if (userId != null && !userId.isEmpty()) {
                DocumentReference userDocRef = mfirestore.collection("Usuario").document(userId);
                CollectionReference registrosPresionRef = userDocRef.collection("registrosPresion");
                Map<String, Object> datos = new HashMap<>();
                datos.put("fechaHora", obtenerFechaHoraActual());
                datos.put("presion", presion);
                registrosPresionRef.add(datos)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Toast.makeText(getContext(), "Datos registrados exitosamente", Toast.LENGTH_SHORT).show();
                                dismiss();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getContext(), "Error al registrar los datos", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        }
    }

    // Obtiene la instancia del usuario actualmente autenticado a través de Firebase Authentication
    // Verifica que el usuario no sea nulo, obtiene su nombre de usuario y lo utiliza para construir una identificación de usuario al eliminar los espacios en blanco
    // Se obtiene una referencia al documento de registro específico dentro de la subcolección "registrosPresion" del usuario
    // Se crea nuevament el mapa de datos con los datos y se actualiza

    private void actualizarRegPre(String documentId, String presion) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreUsuario = user.getDisplayName();
            String userId = nombreUsuario.replaceAll("\\s", "");
            if (userId != null && !userId.isEmpty()) {
                DocumentReference regDocRef = mfirestore.collection("Usuario")
                        .document(userId).collection("registrosPresion").document(documentId);
                Map<String, Object> datos = new HashMap<>();
                datos.put("fechaHora", obtenerFechaHoraActual());
                datos.put("presion", presion);
                regDocRef.update(datos)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(getContext(),
                                        "Registro actualizado exitosamente", Toast.LENGTH_SHORT).show();
                                dismiss();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getContext(),
                                        "Error al actualizar el registro", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        }
    }

    // Metodo para obtener la fecha y la hora

    private String obtenerFechaHoraActual() {
        Date fechaHoraActual = new Date();
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
        return formato.format(fechaHoraActual);
    }
}
