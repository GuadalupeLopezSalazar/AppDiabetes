package mx.edu.tesoem.proyecto1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

public class Menu extends AppCompatActivity {

    Button btnSalir;
    TextView txtNombreUser;
    ImageView btnPerfil;
    FrameLayout btnGlucosa, btnPresion;
    FirebaseAuth mAuth;
    FirebaseFirestore mFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_menu);

        mFirestore = FirebaseFirestore.getInstance();

        // Referenciar vistas

        txtNombreUser = findViewById(R.id.txtNombreUser);
        btnSalir = findViewById(R.id.btnFinalizar);
        btnGlucosa = findViewById(R.id.btn_Glucosa);
        btnPresion = findViewById(R.id.btn_Presion);
        btnPerfil = findViewById(R.id.img_btnPerfil);
        mAuth = FirebaseAuth.getInstance();

        // Dirige e inicia a la actividad Perfil

        btnPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Menu.this, Perfil.class)); // iniciar actividad Perfil
            }
        });

        // Obtiene la instancia del usuario actualmente autenticado a través de Firebase Authentication
        // Verifica que el usuario no sea nulo, obtiene su nombre de usuario y lo utiliza para construir una identificación de usuario al eliminar los espacios en blanco
        // Se obtiene una referencia al documento del usuario en la colección "Usuario"
        // Se realiza una consulta para obtener el documento del usuario con la identificación proporcionada
        // Si el documento existe, se obtiene el valor del campo "PrimerNombre" del documento y se establece en el TextView


        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreUsuario = user.getDisplayName();
            String userId = nombreUsuario.replaceAll("\\s", "");

            DocumentReference userDocRef = mFirestore.collection("Usuario").document(userId);

            mFirestore.collection("Usuario")
                    .document(userId)
                    .get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {
                                String PrimerNombre = documentSnapshot.getString("PrimerNombre");
                                if (PrimerNombre != null) {
                                    txtNombreUser.setText(PrimerNombre);
                                }
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // Manejar el fallo de la consulta
                        }
                    });
        }

        // Dirige e inicia a la actividad MainActivity

        btnSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                finish();
                startActivity(new Intent(Menu.this,MainActivity.class));
            }
        });

        // Dirige e inicia a la actividad RegGlucosa

        btnGlucosa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Menu.this, RegGlucosa.class));
            }
        });

        // Dirige e inicia a la actividad RegPreion

        btnPresion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {startActivity(new Intent(Menu.this, RegPresion.class));
            }
        });
    }





}