package mx.edu.tesoem.proyecto1;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class CheckSintomas extends DialogFragment {

    private static final String ARG_IMC = "imc";
    private FirebaseFirestore mfirestore;
    private float imc;

    public static CheckSintomas newInstance(float imc) {
        CheckSintomas fragment = new CheckSintomas();
        Bundle args = new Bundle();
        args.putFloat(ARG_IMC, imc);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mfirestore = FirebaseFirestore.getInstance();
        if (getArguments() != null) {
            imc = getArguments().getFloat(ARG_IMC);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_check_sintomas, container, false);

        // Find the ImageView and set its onClickListener
        ImageView btnRegresar = view.findViewById(R.id.imageView3);
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        // Find the checkboxes
        CheckBox checkVision = view.findViewById(R.id.checkVision);
        CheckBox checkHambre = view.findViewById(R.id.checkHambre);
        CheckBox checkSed = view.findViewById(R.id.checkSed);
        CheckBox checkCansancio = view.findViewById(R.id.checkCansancio);
        CheckBox checkPielSeca = view.findViewById(R.id.checkPielSeca);
        CheckBox checkIrritabilidad = view.findViewById(R.id.checkIrritabilidad);
        CheckBox checkOrinar = view.findViewById(R.id.checkOrinar);
        CheckBox checkPerdidaPeso = view.findViewById(R.id.checkPerdidaPeso);
        CheckBox checkHeridas = view.findViewById(R.id.checkHeridas);
        CheckBox checkHormigueoPie = view.findViewById(R.id.checkHormigueoPie);
        CheckBox checkNinguno = view.findViewById(R.id.checkNinguno);

        Button btnAceptar = view.findViewById(R.id.button2);

        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkNinguno.isChecked()) {
                    // Mostrar mensaje específico si se selecciona "Ninguno de los síntomas"
                    showAlert("Sin síntomas");
                    dismiss();
                    return;
                }

                // Collect the checked symptoms
                Map<String, Boolean> sintomas = new HashMap<>();
                sintomas.put("Vision borrosa", checkVision.isChecked());
                sintomas.put("Mucha hambre", checkHambre.isChecked());
                sintomas.put("Mucha sed", checkSed.isChecked());
                sintomas.put("Cansancio", checkCansancio.isChecked());
                sintomas.put("Piel muy seca", checkPielSeca.isChecked());
                sintomas.put("Irritabilidad", checkIrritabilidad.isChecked());
                sintomas.put("Orinar con frecuencia", checkOrinar.isChecked());
                sintomas.put("Pérdida inexplicable de peso", checkPerdidaPeso.isChecked());
                sintomas.put("Heridas o llagas que no se curan", checkHeridas.isChecked());
                sintomas.put("Sensación de hormigueo en los pies", checkHormigueoPie.isChecked());
                sintomas.put("Ninguno", checkNinguno.isChecked());

                // Determine the type of diabetes based on selected symptoms and IMC
                int countTipo1 = 0;
                int countTipo2 = 0;

                if (checkSed.isChecked()) countTipo1++;
                if (checkOrinar.isChecked()) countTipo1++;
                if (checkHambre.isChecked()) countTipo1++;
                if (checkVision.isChecked()) countTipo1++;
                if (checkCansancio.isChecked()) countTipo1++;
                if (checkPielSeca.isChecked()) countTipo1++;
                if (checkIrritabilidad.isChecked()) countTipo1++;

                if (checkSed.isChecked()) countTipo2++;
                if (checkOrinar.isChecked()) countTipo2++;
                if (checkHambre.isChecked()) countTipo2++;
                if (checkCansancio.isChecked()) countTipo2++;
                if (checkVision.isChecked()) countTipo2++;
                if (checkHormigueoPie.isChecked()) countTipo2++;
                if (checkHeridas.isChecked()) countTipo2++;
                if (checkPerdidaPeso.isChecked()) countTipo2++;
                if (checkIrritabilidad.isChecked()) countTipo2++;

                // Factoring in IMC for determining diabetes type
                final String resultado;
                if (countTipo2 > 6 || imc >= 25) {
                    resultado = "Diabetes tipo 2";
                } else if (countTipo1 > 4 || imc < 25) {
                    resultado = "Diabetes tipo 1";
                } else {
                    resultado = "Sin diagnóstico";
                }

                // Show the alert dialog
                showAlert(resultado);

                // Save symptoms and result to Firestore
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if (user != null) {
                    String nombreUsuario = user.getDisplayName();
                    String userId = nombreUsuario.replaceAll("\\s", "");

                    DocumentReference userDocRef = mfirestore.collection("Usuario").document(userId);
                    CollectionReference sintomasRef = userDocRef.collection("Sintomas");

                    sintomasRef.add(sintomas)
                            .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentReference> task) {
                                    if (task.isSuccessful()) {
                                        DocumentReference sintomasDocRef = task.getResult();
                                        CollectionReference detallesRef = sintomasDocRef.collection("detalles");

                                        Map<String, Object> detalles = new HashMap<>();
                                        detalles.put("resultado", resultado);

                                        detallesRef.add(detalles)
                                                .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<DocumentReference> task) {
                                                        if (task.isSuccessful()) {
                                                            // Detalles almacenados correctamente
                                                        } else {
                                                            // Error al almacenar los detalles
                                                        }
                                                    }
                                                });
                                    } else {
                                        // Error al almacenar los síntomas
                                    }
                                }
                            });
                }

                dismiss();
            }
        });

        return view;
    }

    private void showAlert(String tipoDiabetes) {
        String mensaje;
        if ("Sin síntomas".equals(tipoDiabetes)) {
            mensaje = "No padeces ningún tipo de diabetes.";
        } else if ("Sin diagnóstico".equals(tipoDiabetes)) {
            mensaje = "De acuerdo a los síntomas seleccionados te encuentras fuera de la probabilidad de padecer diabetes, pero te recomendamos acudir al médico.";
        } else {
            mensaje = "De acuerdo a los síntomas seleccionados es posible que padezcas " + tipoDiabetes + ", te recomendamos que acudas al médico.";
        }

        new AlertDialog.Builder(getContext())
                .setTitle("Resultado de los síntomas")
                .setMessage(mensaje)
                .setPositiveButton("Aceptar", null)
                .show();
    }
}