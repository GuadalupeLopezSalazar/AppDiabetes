package mx.edu.tesoem.proyecto1;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

public class MainActivity extends AppCompatActivity {
    // Definición de constantes y variables de clase
    private static final String TAG = "MainActivity";
    private static final int RC_SIGN_IN = 1; // Código de solicitud para el inicio de sesión con Google
    private GoogleSignInClient mGoogleSignInClient; // Cliente de inicio de sesión de Google

    ImageButton btnGmail;
    Button btnRegistrar, btnIngresar;
    EditText edtCorreoL, edtContraL;
    FirebaseAuth mAuth; // Autenticación de Firebase

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Establece el diseño de la actividad

        // Configuración de opciones de inicio de sesión de Google
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        // Inicialización del cliente de inicio de sesión de Google
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        // Inicialización de Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Referencias a los elementos de la interfaz de usuario
        edtCorreoL = findViewById(R.id.edtCorreoLogin);
        edtContraL = findViewById(R.id.edtContraLogin);
        btnRegistrar = findViewById(R.id.btnRegistrar);
        btnIngresar = findViewById(R.id.btnIngresar);
        btnGmail = findViewById(R.id.imgbtnGmail);

        // Configuración del botón de ingreso
        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtención de los datos ingresados por el usuario
                String correoUsuarioL = edtCorreoL.getText().toString().trim();
                String contraUsuarioL = edtContraL.getText().toString().trim();

                // Verificación de campos vacíos
                if (correoUsuarioL.isEmpty() || contraUsuarioL.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Complete los datos.", Toast.LENGTH_SHORT).show();
                } else {
                    // Llamada al método de ingreso de usuario
                    IngresaUsuario(correoUsuarioL, contraUsuarioL);
                }
            }
        });

        // Configuración del botón de registro
        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegación a la actividad de registro
                startActivity(new Intent(MainActivity.this, RegistroActivity.class));
            }
        });

        // Configuración del botón de inicio de sesión con Google
        btnGmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Llamada al método de inicio de sesión con Google
                signIn();
            }
        });
    }

    // Método para iniciar sesión con correo y contraseña
    private void IngresaUsuario(String correoUsuarioL, String contraUsuarioL) {
        // Verificación del formato del correo electrónico
        if (!isValidEmail(correoUsuarioL)) {
            Toast.makeText(MainActivity.this, "Formato de correo electrónico incorrecto", Toast.LENGTH_SHORT).show();
            return;
        }

        // Inicio de sesión con Firebase Auth
        mAuth.signInWithEmailAndPassword(correoUsuarioL, contraUsuarioL).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    // Si el inicio de sesión es exitoso, se navega a la actividad del menú
                    finish();
                    startActivity(new Intent(MainActivity.this, Menu.class));
                    Toast.makeText(MainActivity.this, "Bienvenido", Toast.LENGTH_SHORT).show();
                } else {
                    // Si el inicio de sesión falla, se muestra un mensaje de error
                    Toast.makeText(MainActivity.this, "Correo o Contraseña incorrecta", Toast.LENGTH_SHORT).show();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                // Manejo de errores en el inicio de sesión
                Toast.makeText(MainActivity.this, "Error al iniciar Sesion", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Método para verificar si el correo electrónico es válido
    private boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    // Método para iniciar sesión con Google
    private void signIn() {
        // Cierra la sesión actual de Google (si existe) y luego inicia una nueva
        mGoogleSignInClient.signOut().addOnCompleteListener(this, new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, RC_SIGN_IN);
            }
        });
    }

    // Manejo del resultado de la actividad de inicio de sesión
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Si el inicio de sesión con Google es exitoso, se obtiene la cuenta de Google
                GoogleSignInAccount account = task.getResult(ApiException.class);
                // Autentica con Firebase usando el token de Google
                firebaseAuthWithGoogle(account.getIdToken());
            } catch (ApiException e) {
                Log.e(TAG, "Error al iniciar sesión con Google", e);
                Toast.makeText(MainActivity.this, "Error al iniciar sesión con Google", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Autentica con Firebase usando las credenciales de Google
    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Si el inicio de sesión es exitoso, se obtiene el usuario actual
                            FirebaseUser user = mAuth.getCurrentUser();
                            // Actualiza la interfaz de usuario con la información del usuario
                            updateUI(user);
                        } else {
                            // Si el inicio de sesión falla, se muestra un mensaje de error
                            Log.w(TAG, "Error", task.getException());
                            Toast.makeText(MainActivity.this, "Error al iniciar sesión con Google", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    // Actualiza la interfaz de usuario después del inicio de sesión
    private void updateUI(FirebaseUser user) {
        if (user != null) {
            Toast.makeText(MainActivity.this, "Bienvenido " + user.getDisplayName(), Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this, Menu.class));
            finish();
        } else {
            // Manejo del caso donde el usuario es nulo
        }
    }

    // Verifica si ya hay un usuario autenticado al iniciar la actividad
    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser usuario = mAuth.getCurrentUser();
        if (usuario != null) {
            startActivity(new Intent(MainActivity.this, Menu.class));
            finish();
        }
    }
}
