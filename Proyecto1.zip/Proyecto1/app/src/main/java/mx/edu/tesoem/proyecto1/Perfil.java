package mx.edu.tesoem.proyecto1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.DocumentSnapshot;

public class Perfil extends AppCompatActivity implements RegistrarDatosExtrasU.RegistrarDatosExtrasListener {

    TextView txtNombre, txtCorreo, txtPeso, txtAltura, txtEdad, txtImc;
    ImageView img_btnAgregarDatos, imgIMC;
    ImageView btnRegresar;
    FirebaseFirestore mFirestore;

    Button btnSintomas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_perfil);

        mFirestore = FirebaseFirestore.getInstance();

        txtNombre = findViewById(R.id.txtNombreP);
        txtCorreo = findViewById(R.id.txtCorreoP);
        txtPeso = findViewById(R.id.txtPesoP);
        txtAltura = findViewById(R.id.txtAlturaP);
        txtEdad = findViewById(R.id.txtEdadP);
        btnRegresar = findViewById(R.id.img_btnRegresar3);
        txtImc = findViewById(R.id.txtImc);
        btnSintomas = findViewById(R.id.btnSintomas);
        img_btnAgregarDatos = findViewById(R.id.img_btnAgregarDatos);
        imgIMC = findViewById(R.id.ImgIMC);

        img_btnAgregarDatos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickAgregarDatosExtras(view);
            }
        });

        btnSintomas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClickSintomas(view);
            }
        });

        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Perfil.this, MainActivity.class));
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarDatosUsuario();
    }

    public void onClickSintomas(View view) {
        float imc = calcularIMC(); // Método para obtener el valor del IMC calculado
        CheckSintomas cr = CheckSintomas.newInstance(imc);
        cr.show(getSupportFragmentManager(), "Sintomas");
    }
    private float calcularIMC() {
        String pesoStr = txtPeso.getText().toString();
        String alturaStr = txtAltura.getText().toString();

        if (!pesoStr.isEmpty() && !alturaStr.isEmpty()) {
            float peso = Float.parseFloat(pesoStr);
            float altura = Float.parseFloat(alturaStr);
            return peso / (altura * altura);
        }

        return 0; // Valor por defecto en caso de error
    }

    private void cargarDatosUsuario() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreCompleto = user.getDisplayName();
            String correo = user.getEmail();
            txtNombre.setText(nombreCompleto);
            txtCorreo.setText(correo);

            cargarDatosExtraUsuario();
        }
    }

    public void cargarDatosExtraUsuario() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreUsuario = user.getDisplayName();
            String userId = nombreUsuario.replaceAll("\\s", "");

            DocumentReference userDocRef = mFirestore.collection("Usuario").document(userId);
            userDocRef.collection("datosExtra")
                    .orderBy("timestamp", Query.Direction.DESCENDING)
                    .limit(1)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful() && !task.getResult().isEmpty()) {
                                DocumentSnapshot document = task.getResult().getDocuments().get(0);
                                String peso = document.getString("peso");
                                String altura = document.getString("altura");
                                String edad = document.getString("edad");
                                txtPeso.setText(peso);
                                txtAltura.setText(altura);
                                txtEdad.setText(edad);

                                // Convertir peso y altura a números flotantes
                                float pesof = Float.parseFloat(peso);
                                float alturaf = Float.parseFloat(altura);

                                // Aplicamos formula del IMC
                                float imc = pesof / (alturaf * alturaf);

                                txtImc.setText(String.format("Indice de masa corporal = %.2f", imc));

                                if (imc > 18.5 && imc < 24.9) {
                                    imgIMC.setImageResource(R.drawable.pesonormal);
                                } else if (imc > 25 && imc < 29.9) {
                                    imgIMC.setImageResource(R.drawable.sobrepeso);
                                } else {
                                    imgIMC.setImageResource(R.drawable.obesidad);
                                }
                            } else {
                                Toast.makeText(Perfil.this, "Error al cargar datos extra", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }

    public void onClickAgregarDatosExtras(View view) {
        RegistrarDatosExtrasU registrarDatosExtrasU = new RegistrarDatosExtrasU();
        registrarDatosExtrasU.setRegistrarDatosExtrasListener(this);
        registrarDatosExtrasU.show(getSupportFragmentManager(), "insertar registro");
    }

    @Override
    public void onDatosExtrasRegistrados() {
        cargarDatosUsuario();
    }
}
