package mx.edu.tesoem.proyecto1.adapter;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

import mx.edu.tesoem.proyecto1.CrearRegPresion;
import mx.edu.tesoem.proyecto1.R;
import mx.edu.tesoem.proyecto1.model.presion;

public class presionAdapter extends FirestoreRecyclerAdapter<presion, presionAdapter.ViewHolder> {

    private Context mContext;

    public presionAdapter(@NonNull FirestoreRecyclerOptions<presion> options, Context context) {
        super(options);
        this.mContext = context;
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull presion model) {
        holder.bind(model);

        holder.imageViewP4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSnapshots().getSnapshot(position).getReference().delete();
            }
        });

        holder.imageViewP5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener la posición del elemento clickeado
                int position = holder.getAdapterPosition();
                // Obtener el ID del documento del registro
                String documentId = getSnapshots().getSnapshot(position).getId();
                // Obtener la fecha y valor del registro
                String fechaHora = model.getFechaHora();
                // Obtener la presión del registro
                String presionString = model.getPresion();
                String[] parts = presionString.split("/");
                int presion = Integer.parseInt(parts[0]); // Convertir la parte antes de '/' a un entero

                // Abrir CrearRegGlucosa con los datos del registro
                CrearRegPresion fragment = new CrearRegPresion();
                Bundle bundle = new Bundle();
                bundle.putString("documentId", documentId);
                bundle.putString("fechaHora", fechaHora);
                bundle.putInt("valor", presion);
                fragment.setArguments(bundle);
                fragment.show(((FragmentActivity) mContext).getSupportFragmentManager(), "editar registro");
            }
        });

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_presion, parent, false);
        return new ViewHolder(view);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView fechaHoraTextView;
        private TextView presionTextView;
        private ImageView imageViewP4;
        private ImageView imageViewP5;
        private ImageView imageViewP3;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            fechaHoraTextView = itemView.findViewById(R.id.txtFyH);
            presionTextView = itemView.findViewById(R.id.txtIndicador);
            imageViewP4 = itemView.findViewById(R.id.imageView4);
            imageViewP5 = itemView.findViewById(R.id.imageView5);
            imageViewP3 = itemView.findViewById(R.id.descripcion);
        }

        public void bind(presion model) {
            fechaHoraTextView.setText(model.getFechaHora());
            presionTextView.setText(model.getPresion());
            actualizarPresion(model);
        }

        private int obtenerImagenSegunPresion(int valorSistolica, int valorDiastolica) {
            if (valorSistolica >= 80 && valorDiastolica >= 50 && valorSistolica <= 90 && valorDiastolica <= 60) {
                return R.drawable.bajo;
            } else if (valorSistolica > 90 && valorDiastolica > 60 && valorSistolica <= 120 && valorDiastolica <= 80) {
                return R.drawable.normal;
            } else if (valorSistolica > 120 && valorDiastolica > 80 && valorSistolica <= 140 && valorDiastolica <= 90) {
                return R.drawable.regular;
            } else if (valorSistolica > 140 && valorDiastolica > 90 && valorSistolica <= 160 && valorDiastolica <= 100) {
                return R.drawable.alto;
            } else if (valorSistolica > 160 && valorDiastolica > 100 && valorSistolica <= 180 && valorDiastolica <= 110) {
                return R.drawable.critico;
            } else if (valorSistolica < 120 && valorDiastolica < 80) {
                return R.drawable.normal;
            } else if (valorSistolica >= 120 && valorSistolica <= 129 && valorDiastolica < 80) {
                return R.drawable.alto;
            } else if (valorSistolica >= 130 || valorDiastolica >= 80) {
                return R.drawable.critico;
            } else {
                return R.drawable.perfil;
            }
        }
        private void actualizarPresion(presion model) {
            String[] presionParts = model.getPresion().split("/");
            int valorSistolica = Integer.parseInt(presionParts[0]);
            int valorDiastolica = Integer.parseInt(presionParts[1]);

            Log.d("ActualizarPresion", "Valores: Sistolica=" + valorSistolica + ", Diastolica=" + valorDiastolica);

            int imagenResourceId = obtenerImagenSegunPresion(valorSistolica, valorDiastolica);

            imageViewP3.setImageResource(imagenResourceId);
        }


    }
    }


