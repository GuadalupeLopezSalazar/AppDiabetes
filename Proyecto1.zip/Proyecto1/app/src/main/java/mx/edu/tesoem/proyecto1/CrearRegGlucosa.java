package mx.edu.tesoem.proyecto1;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CrearRegGlucosa extends DialogFragment {

    TextView txtFechaHora;
    NumberPicker numberPicker;
    Button btnEnviarReg;
    FirebaseFirestore mfirestore;
    String documentId;
    String userId;
    ImageView btnRegresar;
    int valor;

    CheckBox checkAntesComer, checkDespuesComer;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_crear_reg_glucosa, container, false);
        mfirestore = FirebaseFirestore.getInstance();

        // Referenciar vistas
        txtFechaHora = v.findViewById(R.id.txtFechaHora);
        numberPicker = v.findViewById(R.id.numPickerr);
        btnEnviarReg = v.findViewById(R.id.btnAceptar);
        btnRegresar = v.findViewById(R.id.img_btnRegresar6);

        checkAntesComer = v.findViewById(R.id.checkAntesComer);
        checkDespuesComer = v.findViewById(R.id.checkDespuesComer);

        Bundle bundle = getArguments();
        if (bundle != null) {
            documentId = bundle.getString("documentId");
            valor = bundle.getInt("valor", 60); // valor predeterminado comienza desde 60
        }

        // Configurar NumberPicker
        numberPicker.setMinValue(60);  // Establecer el valor mínimo como 60
        numberPicker.setMaxValue(400);  // Establecer el valor máximo como 400 o el valor deseado
        numberPicker.setWrapSelectorWheel(true);

        // Asegurar que el valor inicial no sea menor que el mínimo
        if (valor < 60) {
            valor = 60;
        }

        numberPicker.setValue(valor);

        // Obtener y mostrar la fecha y hora actual
        String fechaHoraActual = obtenerFechaHoraActual();
        txtFechaHora.setText(fechaHoraActual);

        // Definir las imágenes según los rangos
        final ImageView imageView = v.findViewById(R.id.imageView);

        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                Log.d("NumberPicker", "Valor seleccionado: " + newVal);
                actualizarImagen(newVal, imageView);
            }
        });

        // Configurar los CheckBox para que solo se pueda seleccionar uno a la vez
        checkAntesComer.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkDespuesComer.setChecked(false);
                }
            }
        });

        checkDespuesComer.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    checkAntesComer.setChecked(false);
                }
            }
        });

        // Obtiene el valor del numberPicker y verifica los rangos al enviar el registro
        btnEnviarReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int valorSeleccionado = numberPicker.getValue();
                if (documentId != null && !documentId.isEmpty()) {
                    actualizarReg(documentId, valorSeleccionado);
                } else {
                    evaluarYEnviarReg(valorSeleccionado);
                }
            }
        });

        // Dirige e inicia a la actividad RegGlucosa
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        return v;
    }

    // Método para obtener la fecha y la hora
    private String obtenerFechaHoraActual() {
        Date fechaHoraActual = new Date();
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
        return formato.format(fechaHoraActual);
    }

    // Método para obtener el texto de los CheckBox seleccionados
    private String obtenerTextoCheckBoxSeleccionado() {
        if (checkAntesComer.isChecked()) {
            return checkAntesComer.getText().toString();
        } else if (checkDespuesComer.isChecked()) {
            return checkDespuesComer.getText().toString();
        }
        return null;
    }

    // Método para evaluar y enviar registro con verificación de rangos
    private void evaluarYEnviarReg(int valor) {
        String rango = evaluarRangoGlucosa(valor);
        Log.d("CrearRegGlucosa", "Rango evaluado: " + rango);
        if (rango.equals("Hipoglucemia")) {
            mostrarMensaje("Tu nivel de glucosa es bajo, considera consumir una fuente rápida de carbohidratos para elevarlo");
        } else if (rango.equals("Normal")) {
            mostrarMensaje("Tu nivel de glucosa está dentro del rango saludable");
        } else if (rango.equals("Prediabetes")) {
            mostrarMensaje("Tu nivel de glucosa indica prediabetes, es importante hacer cambios en el estilo de vida para prevenir la diabetes");
        } else if (rango.equals("Diabetes")) {
            mostrarMensaje("Tu nivel de glucosa indica diabetes, es recomendable que consultes a tu médico");
        }

        if (checkDespuesComer.isChecked() && valor > 140) {
            CheckFragment check = new CheckFragment();
            Bundle bundle = new Bundle();
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            String nombreUsuario = user.getDisplayName();
            String userId = nombreUsuario.replaceAll("\\s", "");
            bundle.putString("documentId", userId);  // Pasar el documentId al fragmento
            check.setArguments(bundle);
            check.show(requireActivity().getSupportFragmentManager(), "insertar Alimentos");
        }

        enviarReg(valor, rango);
    }



    private String evaluarRangoGlucosa(int valor) {
        if (checkAntesComer.isChecked()) {
            if (valor < 70) {
                return "Hipoglucemia";
            } else if (valor >= 70 && valor < 100) {
                return "Normal";
            } else if (valor >= 100 && valor <= 125) {
                return "Prediabetes";
            } else {
                return "Diabetes";
            }
        } else if (checkDespuesComer.isChecked()) {
            if (valor < 70) {
                return "Hipoglucemia";
            } else if (valor >= 70 && valor < 140) {
                return "Normal";
            } else if (valor >= 140 && valor <= 199) {
                return "Prediabetes";
            } else {
                return "Diabetes";
            }
        } else { // Cualquier momento del día
            if (valor < 70) {
                return "Hipoglucemia";
            } else if (valor >= 70 && valor < 140) {
                return "Normal";
            } else if (valor >= 140 && valor < 250) {
                return "Prediabetes";
            } else {
                return "Diabetes";
            }
        }
    }

    // Método para actualizar la imagen según el rango de glucosa
    private void actualizarImagen(int valor, ImageView imageView) {
        if (checkAntesComer.isChecked()) {
            if (valor < 70) {
                imageView.setImageResource(R.drawable.bajo);
            } else if (valor >= 70 && valor < 100) {
                imageView.setImageResource(R.drawable.normal);
            } else if (valor >= 100 && valor <= 125) {
                imageView.setImageResource(R.drawable.regular);
            } else {
                imageView.setImageResource(R.drawable.alto);
            }
        } else if (checkDespuesComer.isChecked()) {
            if (valor < 70) {
                imageView.setImageResource(R.drawable.bajo);
            } else if (valor >= 70 && valor < 140) {
                imageView.setImageResource(R.drawable.normal);
            } else if (valor <= 199) {
                imageView.setImageResource(R.drawable.regular);
            } else {
                imageView.setImageResource(R.drawable.alto);
            }
        } else { // Cualquier momento del día
            if (valor < 70) {
                imageView.setImageResource(R.drawable.bajo);
            } else if (valor >= 70 && valor < 140) {
                imageView.setImageResource(R.drawable.normal);
            } else if (valor >= 140 && valor < 250) {
                imageView.setImageResource(R.drawable.regular);
            } else {
                imageView.setImageResource(R.drawable.alto);
            }
        }
    }

    private void enviarReg(int valor, String rango) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreUsuario = user.getDisplayName();
            String userId = nombreUsuario.replaceAll("\\s", "");
            DocumentReference userDocRef = mfirestore.collection("Usuario").document(userId);
            CollectionReference registrosGlucosaRef = userDocRef.collection("registrosGlucosa");

            // Generar un ID personalizado usando la fecha y hora actual
            String documentId = obtenerIdDocumento();

            Map<String, Object> datos = new HashMap<>();
            datos.put("id", documentId);  // Agregar el ID personalizado
            datos.put("fechaHora", obtenerFechaHoraActual());
            datos.put("valor", valor);
            datos.put("rango", rango);
            String textoCheckBoxSeleccionado = obtenerTextoCheckBoxSeleccionado();
            if (textoCheckBoxSeleccionado != null) {
                datos.put("check", textoCheckBoxSeleccionado);
            }

            registrosGlucosaRef.document(documentId).set(datos)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(requireContext(), "Datos registrados exitosamente", Toast.LENGTH_SHORT).show();
                            dismiss();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(requireContext(), "Error al registrar los datos", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    private void actualizarReg(String documentId, int valor) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreUsuario = user.getDisplayName();
            String userId = nombreUsuario.replaceAll("\\s", "");
            if (userId != null && !userId.isEmpty()) {
                DocumentReference docRef = mfirestore.collection("Usuario").document(userId).collection("registrosGlucosa").document(documentId);

                Map<String, Object> datos = new HashMap<>();
                datos.put("valor", valor);
                datos.put("fechaHora", obtenerFechaHoraActual());
                String textoCheckBoxSeleccionado = obtenerTextoCheckBoxSeleccionado();
                if (textoCheckBoxSeleccionado != null) {
                    datos.put("check", textoCheckBoxSeleccionado);
                }

                docRef.set(datos)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(requireContext(), "Registro actualizado exitosamente", Toast.LENGTH_SHORT).show();
                                dismiss();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(requireContext(), "Error al actualizar el registro", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        }
    }

    // Método para obtener el ID del documento personalizado (fecha y hora actual)
    private String obtenerIdDocumento() {
        Date fechaHoraActual = new Date();
        SimpleDateFormat formato = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
        return formato.format(fechaHoraActual);
    }


    // Método para mostrar mensajes AlertDialog
    private void mostrarMensaje(String mensaje) {
        if (isAdded()) { // Verificar que el fragmento esté adjunto a la actividad
            AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
            builder.setMessage(mensaje)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // Acción al hacer clic en OK
                        }
                    });
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }
}
